
const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const services = require('./getaway.json')

const app = express();

for (let index = 0; index < services.length; index++) {
    const ms = services[index];
    console.log(ms)
    app.use(`/${ms.name}`, createProxyMiddleware({
        target: ms.url,
        changeOrigin: true, logLevel: 'debug'
    }));
}

app.listen(5000);
