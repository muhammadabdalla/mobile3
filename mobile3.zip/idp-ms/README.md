# AAIB IDP Microservice


* How to build and run this project 
    * Clone this repo.
    * Make a copy of **.env.example** file to **.env**.
    * Run the following command: npm start
