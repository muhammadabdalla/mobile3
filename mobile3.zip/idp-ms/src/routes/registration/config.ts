export const productOfInterest = {
  account: 'Account',
  creditCard: 'Credit Card',
  loan: 'Loan',
  investment: 'Investment'
};
