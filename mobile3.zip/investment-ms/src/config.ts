// Mapper for environment variables

export const environment = process.env.NODE_ENV;
export const port = process.env.PORT;

export const corsUrl = process.env.CORS_URL;

export const kafkaOptions = {
  clientId: process.env.KAFKA_CLIENT_ID || '',
  hosts: process.env.KAFKA_HOSTS?.split(',') || [],
  connectionTimeout: parseInt(process.env.KAFKA_CONNECTION_TIMEOUT || '3000'),
  requestTimeout: parseInt(process.env.KAFKA_REQUEST_TIMEOUT || '25000'),
  initialRetryTime: parseInt(process.env.KAFKA_INITIAL_RETRY_TIME || '1'),
  retries: parseInt(process.env.KAFKA_RETRIES || '1'),
  producerPolicy: {
    allowAutoTopicCreation: true
  },
  consumerPolicy: {
    groupId: process.env.CONSUMER_GROUP_ID || 'investment-ms',
    maxWaitTimeInMs: Number(process.env.CONSUMER_MAX_WAIT_TIME || '100'),
    allowAutoTopicCreation: true,
    sessionTimeout: Number(process.env.CONSUMER_SESSION_TIMEOUT || '30000'),
    heartbeatInterval: Number(process.env.CONSUMER_HEART_BEAT || '3000'),
    retry: {
      retries: parseInt(process.env.KAFKA_RETRIES || '1')
    }
  },
  numberOfPartitions: Number(process.env.KAFKA_PARTITION_NUMBER || '3')
};

export const kafkaTopics = {
  t24Request: 't24Request',
  investmentResponse: 'investmentResponse',
  validateTopic: 'validateTopic',
  smtp: 'smtp',
  statistics: 'statistics',
  kibana: 'kibanastatistics'
};

export const promiseTimeout = parseInt(process.env.PROMISE_TIMEOUT || '20000');

export const investmentTypes = {
  greenPearls: 'greenPearls',
  certificates: 'certificates',
  timeDeposit: 'timeDeposit',
  mutualFund: 'mutualFund'
};

export const treasuryTypes = {
  treasuryBill: 'treasuryBill',
  treasuryBond: 'treasuryBond',
  zeroBond: 'zeroBond'
};

export const CdSourceOfFund = [
  {
    code: 1,
    ARName: 'القروض',
    ENName: 'Loans'
  },
  {
    code: 2,
    ARName: 'ودائع العملاء القائمة',
    ENName: 'Existing deposits'
  },
  {
    code: 3,
    ARName: 'ودائع جديدة',
    ENName: 'New deposits'
  },
  {
    code: 4,
    ARName: 'تحويلات من بنوك محلية',
    ENName: 'Transfer from local banks'
  },
  {
    code: 5,
    ARName: 'تحويلات من بنوك خارجية',
    ENName: 'Transfer from international banks'
  }
];

export const defaultCurrency = 'EGP';

export const currencies: { [key: string]: string } = {
  EG: 'EGP',
  AE: 'AED'
};

export const countries: { [key: string]: string } = {
  EG: 'EG',
  AE: 'AE'
};

export const cdTypesEnum = {
  FIXED: 'FIXED',
  FLOATING: 'FLOATING',
  BULLET: 'BULLET',
  DISCOUNTED: 'DISCOUNTED',
  FIXED_AND_FLOATING: 'FIXED & FLOATING'
};

export const cdTypesDisplay: { [key: string]: string } = {
  FIXED: 'Fixed Certificate of Deposit',
  FLOATING: 'Floating Certificate of Deposit',
  BULLET: 'Bullet Certificate of Deposit',
  DISCOUNTED: 'Upfront Certificate of Deposit',
  'FIXED & FLOATING': 'Fixed & Floating Certificate of Deposit'
};

export const validCdsTenors = [36, 60, 84, 120];
export const availCdTypes = ['Fixed', 'Bullet', 'Discounted'];

type keyValPair = { [key: string]: string };

export const cdTitle: { [key: string]: keyValPair } = {
  en: {
    Fixed: 'Fixed',
    Floating: 'Floating',
    Bullet: 'Bullet',
    Discounted: 'Upfront'
  },
  ar: {
    Fixed: 'العائد الثابت',
    Floating: 'العائد التراكمي',
    Bullet: 'العائد التراكمي',
    Discounted: 'العائد المدفوع مقدماً'
  }
};

export const cdTypeDesc: { [key: string]: keyValPair } = {
  en: {
    Fixed:
      'Certificate of Deposit with fixed interest rate that will not change through the agreed tenor',
    Floating:
      'Certificate of Deposit with floating interest rate that may change through the agreed tenor',
    Bullet: 'Certificate of Deposit with accumulated interest rate that is paid by maturity',
    Discounted:
      'Certificate of deposit with upfront interest rate that is paid instantly after issuance'
  },
  ar: {
    Fixed: 'شهادة إيداع بسعر فائدة ثابت لن يتغير خلال المدة المتفق عليها',
    Floating: 'شهادة إيداع بسعر فائدة متغير قد يتغير خلال المدة المتفق عليها',
    Bullet: 'شهادة إيداع بسعر فائدة متراكم يتم دفعه عند تاريخ الاستحقاق',
    Discounted: 'شهادة إيداع بسعر فائدة مدفوع مقدماً عند الإصدار'
  }
};

export const cdFrequencyMapping: { [key: string]: keyValPair } = {
  en: {
    '01': 'Monthly',
    '03': 'Quarterly',
    '06': 'Semi-annually',
    '12': 'Annually'
  },
  ar: {
    '01': 'شهري',
    '03': 'ربع سنوي',
    '06': 'نصف سنوي',
    '12': 'سنوي'
  }
};

export const minCdValues = {
  firstTime: 5000,
  otherTimes: 1000
};

export const cloudApiBaseUrl = process.env.CLOUD_API_BASE_URL as string;
export const secureHashInfo = {
  secretKey: process.env.HMAC_SECRET_KEY as string,
  jwtSecret: process.env.SECURE_HASH_JWT_SECRET as string
};
