import { prepareKafkaResponse, produce } from '../../kafka';
import { logger } from '../../core/Logger';
import {
  AuthCDError,
  BadRequestError,
  CDCancelError,
  CDIssuanceNotValid,
  ForbiddenError,
  InternalError
} from '../../core/ApiError';
import * as lodash from 'lodash';
import promiseAllsettled from 'promise.allsettled';
import correlation from 'express-correlation-id';
import {
  availCdTypes,
  cdFrequencyMapping,
  CdSourceOfFund,
  cdTitle,
  cdTypeDesc,
  cdTypesDisplay,
  cdTypesEnum,
  countries,
  currencies,
  defaultCurrency,
  investmentTypes,
  kafkaTopics,
  minCdValues,
  treasuryTypes,
  validCdsTenors,
  cloudApiBaseUrl,
  promiseTimeout,
  secureHashInfo
} from '../../config';
import { SubmitIssuance } from 'app-request';
import updateStatistics from '../../helpers/statistics';
import messages from '../../messages';
import { redemptionTable } from '../../data/redemptionTable';
import { CurrencyDetails } from '../../Interfaces/CurrencyDetails';
import crypto from 'crypto';
import { promisify } from 'util';
import { v1 } from 'uuid';
import axios, { AxiosResponse } from 'axios';
import { sign } from 'jsonwebtoken';

export const getTwinListOfInvestment = async (
  user: any,
  currency: string,
  authorization: string,
  tracingHeaders: any,
  versionNumber: any
) => {
  try {
    const mainCifCurrency = currencies[user.country] || defaultCurrency;
    const depositsCurrencies = new Set();
    const currencyRates = await getConversionRates(defaultCurrency, tracingHeaders);
    let notFetched: any = null;

    const requests = user.allcifs.map(async (cifObj: { country: string; cif: string }) => {
      const cif = parseInt(cifObj.cif);
      const currentCifCurrency = currencies[cifObj.country] || mainCifCurrency;
      depositsCurrencies.add(currentCifCurrency);
      const requestCorrelation = `${correlation.getId()}-${cifObj.cif}`;

      return await getListOfInvestment(
        cif,
        defaultCurrency,
        currentCifCurrency,
        cifObj.country,
        authorization,
        tracingHeaders,
        requestCorrelation,
        currencyRates,
        depositsCurrencies,
        versionNumber
      );
    });

    const results: any = [];
    const res = await promiseAllsettled(requests);

    const hasFulfilledPromise = res.some((result) => result.status === 'fulfilled');

    if (!hasFulfilledPromise) {
      const emptyInveststments = [
        {
          currency: '',
          total: 0,
          gain: 0,
          type: '',
          EGTotal: 0,
          UAETotal: 0,
          EGGain: 0,
          UAEGain: 0,
          count: 0,
          data: []
        }
      ];
      return {
        investments: emptyInveststments,
        isError: true,
        depositsCurrencies: []
      };
    }

    res.forEach((result) => {
      if (result.status === 'fulfilled') {
        results.push(result.value);
      } else {
        notFetched = (result.reason as Error).message;
      }
    });

    let tdsInvestmentcount = 0;
    let cdsInvestmentcount = 0;
    const cdsInvestment: any = { data: [], total: 0, gain: 0 };
    cdsInvestment.dicountedCdsCount = 0;
    cdsInvestment.fixedBulletCdsCount = 0;
    const tdsInvestment: any = { data: [], total: 0, gain: 0 };
    const investments: any = [];

    results.forEach((result: any, index: number) => {
      tdsInvestment.currency = mainCifCurrency;
      tdsInvestment.type = 'timeDeposit';
      tdsInvestment.data.push(...result.investments.timeDeposits?.data);
      tdsInvestmentcount += result.investments.timeDeposits?.count;

      tdsInvestment[`${result.investments.timeDeposits?.country}TotalInEGP`] = Number(
        result.investments.timeDeposits?.total.toFixed(2)
      );
      tdsInvestment[`${result.investments.timeDeposits?.country}GainInEGP`] = Number(
        result.investments.timeDeposits?.gain.toFixed(2)
      );

      tdsInvestment.total += tdsInvestment[`${result.investments.timeDeposits?.country}TotalInEGP`];
      tdsInvestment.gain += tdsInvestment[`${result.investments.timeDeposits?.country}GainInEGP`];

      cdsInvestment.currency = mainCifCurrency;
      cdsInvestment.type = 'certificates';
      cdsInvestment.dicountedCdsCount += result.investments.certificates.dicountedCdsCount || 0;
      cdsInvestment.fixedBulletCdsCount += result.investments.certificates.fixedBulletCdsCount || 0;
      cdsInvestment.data.push(...result.investments.certificates?.data);
      cdsInvestmentcount += result.investments.certificates?.count;
      cdsInvestment[`${result.investments.certificates?.country}TotalInEGP`] = Number(
        result.investments.certificates?.total.toFixed(2)
      );
      cdsInvestment[`${result.investments.certificates?.country}GainInEGP`] = Number(
        result.investments.certificates?.gain.toFixed(2)
      );

      cdsInvestment.total += cdsInvestment[`${result.investments.certificates?.country}TotalInEGP`];
      cdsInvestment.gain += cdsInvestment[`${result.investments.certificates?.country}GainInEGP`];

      if (result.investments.timeDeposits?.currency != defaultCurrency) {
        tdsInvestment[`${result.investments.timeDeposits?.country}Total`] = Number(
          (
            result.investments.timeDeposits?.total /
            currencyRates[result.investments.timeDeposits?.currency].TransferBuyRate
          ).toFixed(2)
        );

        tdsInvestment[`${result.investments.timeDeposits?.country}Gain`] = Number(
          (
            result.investments.timeDeposits?.gain /
            currencyRates[result.investments.timeDeposits?.currency].TransferBuyRate
          ).toFixed(2)
        );

        cdsInvestment[`${result.investments.certificates?.country}Total`] = Number(
          (
            result.investments.certificates?.total /
            currencyRates[result.investments.certificates?.currency].TransferBuyRate
          ).toFixed(2)
        );
        cdsInvestment[`${result.investments.certificates?.country}Gain`] = Number(
          (
            result.investments.certificates?.gain /
            currencyRates[result.investments.certificates?.currency].TransferBuyRate
          ).toFixed(2)
        );
      }
    });

    tdsInvestment.EGTotal = tdsInvestment.EGTotalInEGP;
    tdsInvestment.EGGain = tdsInvestment.EGGainInEGP;

    tdsInvestment.UAETotal = tdsInvestment.AETotal;
    tdsInvestment.UAEGain = tdsInvestment.AEGain;

    cdsInvestment.EGTotal = cdsInvestment.EGTotalInEGP;
    cdsInvestment.EGGain = cdsInvestment.EGGainInEGP;

    cdsInvestment.UAETotal = cdsInvestment.AETotal;
    cdsInvestment.UAEGain = cdsInvestment.AEGain;

    tdsInvestment.count = tdsInvestmentcount;
    cdsInvestment.count = cdsInvestmentcount;

    if ((currency && currency !== mainCifCurrency) || mainCifCurrency != defaultCurrency) {
      const conversionRate: any = await getCurrencyConversionRate(
        currency ? currency : mainCifCurrency,
        currencyRates,
        tracingHeaders
      );

      tdsInvestment.total = Number((tdsInvestment.total * conversionRate.theRate).toFixed(2));

      tdsInvestment.gain = Number((tdsInvestment.gain * conversionRate.theRate).toFixed(2));

      cdsInvestment.total = Number((cdsInvestment.total * conversionRate.theRate).toFixed(2));
      cdsInvestment.gain = Number((cdsInvestment.gain * conversionRate.theRate).toFixed(2));

      tdsInvestment.currency = currency ? currency : mainCifCurrency;
      cdsInvestment.currency = currency ? currency : mainCifCurrency;
    }

    investments.push(tdsInvestment);
    investments.push(cdsInvestment);

    return {
      investments,
      depositsCurrencies: Array.from(depositsCurrencies),
      CDsnTDsCurrencies: Array.from(depositsCurrencies),
      notFetched
    };
  } catch (err) {
    logger.info('Error', err.message);
    return {
      investments: {
        currency: '',
        total: 0,
        gain: 0,
        type: '',
        EGTotal: 0,
        UAETotal: 0,
        EGGain: 0,
        UAEGain: 0,
        count: 0,
        data: []
      },
      isError: true,
      depositsCurrencies: []
    };
  }
};

export const investmentCurrencyRate = (mainCifCurrencyConversions: any, currency: string) => {
  const converstions = mainCifCurrencyConversions;
  const theRawRate = Number(1 / converstions[currency].TransferBuyRate);
  const method = converstions[currency].method;
  const theRate = method === 'M' ? theRawRate : Number(1 / theRawRate);

  return theRate;
};

export const getListOfInvestment = async (
  user: number,
  currencyToConvertTotalAndGainToIt: string,
  currentCifCurrency: string,
  country: string,
  authorization: string,
  tracingHeaders: any,
  requestCorrelation: string,
  currencyRates: any,
  depositsCurrencies: any,
  versionNumber: any
) => {
  try {
    const investments: any = {};
    const [greenPearls, timeDeposit, certificates] = await Promise.all([
      await getInvestments(
        user,
        currencyRates,
        currencyToConvertTotalAndGainToIt,
        currentCifCurrency,
        country,
        `mm/greenpearl/customer/${user}`,
        investmentTypes.greenPearls,
        depositsCurrencies,
        authorization,
        tracingHeaders,
        requestCorrelation
      ),
      await getInvestments(
        user,
        currencyRates,
        currencyToConvertTotalAndGainToIt,
        currentCifCurrency,
        country,
        `mm/timedeposit/customer/${user}`,
        investmentTypes.timeDeposit,
        depositsCurrencies,
        authorization,
        tracingHeaders,
        requestCorrelation
      ),
      await getInvestments(
        user,
        currencyRates,
        currencyToConvertTotalAndGainToIt,
        currentCifCurrency,
        country,
        `ld/certificate/customer/${user}`,
        investmentTypes.certificates,
        depositsCurrencies,
        authorization,
        tracingHeaders,
        requestCorrelation,
        versionNumber
      )
    ]);

    const mergedDeposits = await mergeDeposits(greenPearls, timeDeposit);
    investments.timeDeposits = mergedDeposits;
    const sortedCertificates = certificates;
    sortedCertificates.data = sortRecordsDes(certificates.data, 'AgreementDate');
    investments.certificates = sortedCertificates;
    investments.currency = currentCifCurrency;
    return { investments };
  } catch (e) {
    logger.error(`in ${country}: ${e.message}`);
    throw new Error(`${country}`);
  }
};

export const getInvestments = async (
  user: number,
  currencyRates: any,
  currency: string,
  currentCifCurrency: string,
  country: string,
  route: string,
  type: string,
  depositsCurrencies: any,
  authorization: string,
  tracingHeaders: any,
  requestCorrelation: string,
  versionNumber?: any
) => {
  try {
    let result = [];
    if (country === 'AE' && type === 'certificates') {
      return {
        data: [],
        type,
        total: 0,
        currency: currentCifCurrency,
        gain: 0,
        count: 0,
        country
      };
    } else {
      const data = {
        route,
        authorization,
        country
      };
      const producerData = await produce(data, tracingHeaders, true, requestCorrelation);
      result = await prepareKafkaResponse(producerData);
    }
    const count = result.length;
    let total = 0;
    let gain = 0;
    let dicountedCdsCount = 0;
    let fixedBulletCdsCount = 0;
    for (const item of result) {
      if ((type === 'greenPearls' || type === 'timeDeposit') && item.InterestPaid) {
        if (item.Currency !== currency) {
          if (currencyRates[item.Currency].method === 'M') {
            gain += item.InterestPaid * currencyRates[item.Currency].TransferBuyRate;
          } else {
            gain += item.InterestPaid / currencyRates[item.Currency].TransferBuyRate;
          }
        } else gain += item.InterestPaid;
      } else if (type === 'certificates') {
        const cdType = item.LDTypeDescription.split(' ')[0];
        item.CategoryDescription = cdTypesDisplay[cdType] || item.CategoryDescription;
        if (cdType === cdTypesEnum.DISCOUNTED) {
          item.InterestRate = item.BulletPercent;
          dicountedCdsCount += 1;
        } else if (
          cdType === cdTypesEnum.FIXED ||
          cdType === cdTypesEnum.BULLET ||
          cdType === cdTypesEnum.FLOATING
        ) {
          fixedBulletCdsCount++;
        }
        if (cdType === cdTypesEnum.BULLET && versionNumber && item.BulletPercent !== 0) {
          item.InterestRate = item.BulletPercent;
        }

        if (item.TotalPaid) {
          if (item.Currency !== currency) {
            if (currencyRates[item.Currency].method === 'M') {
              gain += item.TotalPaid * currencyRates[item.Currency].TransferBuyRate;
            } else {
              gain += item.TotalPaid / currencyRates[item.Currency].TransferBuyRate;
            }
          } else {
            gain += item.TotalPaid;
          }
        }
      }

      if (!item.Amount) item.Amount = item.LDAmount || item.Price;
      if (item.Currency !== currency) {
        if (currencyRates[item.Currency].method === 'M')
          total += item.Amount * currencyRates[item.Currency].TransferBuyRate;
        else total += item.Amount / currencyRates[item.Currency].TransferBuyRate;
      } else {
        total += item.Amount;
      }
      item.country = country;
      depositsCurrencies.add(item.Currency);
    }

    return {
      data: result,
      type,
      total,
      currency: currentCifCurrency,
      gain,
      count,
      country,
      dicountedCdsCount,
      fixedBulletCdsCount
    };
  } catch (e) {
    logger.error(`in ${country}: ${e.message}`);
    throw new Error(`${country}`);
  }
};

export const getConversionRates = async (
  currency: string,
  tracingHeaders?: any,
  requestCorrelation?: string
): Promise<any> => {
  const result = await getCurrenciesExchangeRatesService(currency || 'EGP');
  const conversion: { [key: string]: any } = {};
  for (const item of result) {
    conversion[item.CurrencyCode] = {
      TransferBuyRate: item.TransferBuyRate,
      TransferSellRate: item.TransferSellRate,
      method: item.CurrencyMultiplyDivider
    };
  }
  return conversion;
};

export const getConversionRatesT24 = async (
  currency: string,
  tracingHeaders?: any,
  requestCorrelation?: string
) => {
  const data = {
    route: `rates/exchange/${currency}`
  };
  const producerData = await produce(data, tracingHeaders, true, requestCorrelation);
  const result = await prepareKafkaResponse(producerData);
  const conversion: { [key: string]: any } = {};
  for (const item of result) {
    conversion[item.CurrencyCode] = {
      TransferBuyRate: item.TransferBuyRate,
      TransferSellRate: item.TransferSellRate,
      method: item.CurrencyMultiplyDivider
    };
  }
  return conversion;
};

const getCurrenciesExchangeRatesService = async (
  baseCurrency: string
): Promise<CurrencyDetails[]> => {
  const endpoint = `/rates/exchange/${baseCurrency.toUpperCase()}`;
  const url = cloudApiBaseUrl + endpoint;
  const secure_hash = await generateSecureHashHeader('GET', endpoint);

  const headerConfig = {
    headers: {
      timeout: promiseTimeout,
      Accept: 'application/json',
      secureHash: 'Bearer ' + secure_hash,
      channel: 'WEB'
    }
  };

  try {
    const result: AxiosResponse = await axios.get(url, headerConfig);
    return result.data?.Data;
  } catch (error) {
    logger.error(error.message);
    throw new InternalError();
  }
};

const generateSecureHashHeader = async (
  method: 'GET' | 'POST',
  endpoint: string
): Promise<string> => {
  const channel = 'WEB';
  const nonce = v1().toString();
  const timeStamp = Date.now().toString();
  const signature = method + endpoint + timeStamp + nonce + channel;

  const HMAC_Signature = crypto
    .createHmac('sha256', String(secureHashInfo.secretKey))
    .update(signature)
    .digest('base64');

  const token = Buffer.from(HMAC_Signature + ':' + nonce + ':' + timeStamp).toString('base64');
  const secureHash = { sub: { userInfo: { channel }, token } };

  // @ts-ignore
  return promisify(sign)(secureHash, secureHashInfo.jwtSecret).catch((err) => {
    logger.error(err);
    throw new InternalError();
  });
};

export const getCurrencyConversionRate = async (
  currency: string,
  conversions: any,
  tracingHeaders?: any
) => {
  try {
    if (currency === defaultCurrency) {
      return { theRate: 1 };
    }
    const currencyConversionFactorToDefaultCurrency = conversions[currency].TransferBuyRate;
    if (!currencyConversionFactorToDefaultCurrency) {
      throw Error("this currency's conversion rate is not available");
    }
    const theRate: number = 1 / currencyConversionFactorToDefaultCurrency;
    return { theRate };
  } catch (e) {
    throw new InternalError(e.message);
  }
};

export const mergeDeposits = async (greenPearls: any, timeDeposit: any) => {
  let mergedData = greenPearls.data.concat(timeDeposit.data);
  const balance = greenPearls.total + timeDeposit.total;
  mergedData = lodash.orderBy(mergedData, ['ValueDate'], ['asc']);
  const gain = greenPearls.gain + timeDeposit.gain;
  const count = greenPearls.count + timeDeposit.count;
  const country = timeDeposit.country || greenPearls.country;
  return {
    data: mergedData,
    type: investmentTypes.timeDeposit,
    total: balance,
    currency: timeDeposit.currency,
    gain: gain,
    count: count,
    country: country
  };
};

export const getMutualFunds = async (
  user: any,
  currency: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const depositsCurrencies = new Set();
    let mainCif: string = user?.cif;
    let EGCif = '';
    if (user?.country != 'EG') {
      const hasEgCif = user.allcifs.some((obj: any) => {
        if (obj.country === 'EG') {
          EGCif = obj.cif;
        }

        return obj.country === 'EG';
      });
      mainCif = hasEgCif ? EGCif : '';
    }
    if (!mainCif) {
      return {
        MutualFunds: [],
        currency,
        total: 0,
        gain: 0,
        allUnits: 0,
        depositsCurrencies: [currencies[user.country]]
      };
    }

    const merged: any = {};
    const data = {
      route: `securities/mutualfund/customer/${mainCif}`,
      authorization
    };
    const producerData = await produce(data, tracingHeaders);
    const result = await prepareKafkaResponse(producerData);
    const currencyRates = await getConversionRates(currency, tracingHeaders);

    result.map((item: any) => {
      if (!merged[item.FundId]) {
        merged[item.FundId] = {
          FundName: item.FundName,
          Currency: item.Currency,
          Price: 0,
          MarketValue: 0,
          InitialPrice: 0,
          Frequency: 0,
          details: [],
          Units: 0,
          country: user.country
        };
      }
      depositsCurrencies.add(item.Currency);
      merged[item.FundId].Units += item.Units;
      merged[item.FundId].InitialPrice += item.InitialPrice * item.Units;
      merged[item.FundId].MarketValue += item.MarketValue;
      merged[item.FundId].Price = item.Price;
      merged[item.FundId].details.push(item);
    });
    const keys: any = Object.keys(merged);
    const finalResponse: any[] = [];
    let frequency = 0;
    let total = 0;
    let gain = 0;
    let allUnits = 0;
    keys.forEach((item: any) => {
      merged[item].FundId = item;
      merged[item].profit = merged[item].MarketValue - merged[item].InitialPrice;
      frequency =
        ((merged[item].MarketValue - merged[item].InitialPrice) /
          (merged[item].InitialPrice || 1)) *
        100;
      merged[item].Frequency = Number(frequency.toFixed(2));
      if (merged[item].Currency !== currency) {
        if (currencyRates[merged[item].Currency].method === 'M') {
          total += merged[item].MarketValue * currencyRates[merged[item].Currency].TransferBuyRate;
          gain += merged[item].profit * currencyRates[merged[item].Currency].TransferBuyRate;
        } else {
          gain += merged[item].profit / currencyRates[merged[item].Currency].TransferBuyRate;
          total += merged[item].MarketValue / currencyRates[merged[item].Currency].TransferBuyRate;
        }
      } else {
        gain += merged[item].profit;
        total += merged[item].MarketValue;
      }

      allUnits += merged[item].Units;
      finalResponse.push(merged[item]);
    });

    return {
      MutualFunds: finalResponse,
      currency,
      total: Number(total.toFixed(2)),
      gain: Number(gain.toFixed(2)),
      allUnits,
      depositsCurrencies: Array.from(depositsCurrencies)
    };
  } catch (e) {
    logger.error(e);
    return {
      MutualFunds: [],
      currency,
      total: 0,
      gain: 0,
      isError: true,
      allUnits: 0,
      depositsCurrencies: [currencies[user.country]]
    };
  }
};

export const getListTreasury = async (
  user: any,
  currency: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const mainCountry = user.country;
    const mainCifCurrency = currencies[mainCountry] || defaultCurrency;
    const depositsCurrencies = new Set();
    const response: any = {};
    for (const cifObj of user.allcifs) {
      const currentCif = parseInt(cifObj.cif);
      const currentCountry = cifObj.country;
      const currentCifcurrency = currencies[cifObj.country] || mainCifCurrency;
      depositsCurrencies.add(currentCifcurrency);
      if (currentCountry !== countries.EG) {
        response.empty = {
          treasury: [],
          currency: currentCifcurrency,
          total: 0,
          billscount: 0,
          bondscount: 0,
          depositsCurrencies: [`${currentCifcurrency}`]
        };
      } else {
        const treasury = [];
        const currencyRates = await getConversionRates(defaultCurrency, tracingHeaders);
        const [treasuryBills, treasuryBond, zeroBonds] = await Promise.all([
          await getTreasury(
            currentCif,
            currencyRates,
            mainCifCurrency,
            `securities/tbill/customer/${currentCif}`,
            treasuryTypes.treasuryBill,
            depositsCurrencies,
            authorization,
            tracingHeaders
          ),
          await getTreasury(
            currentCif,
            currencyRates,
            mainCifCurrency,
            `securities/tbond/customer/${currentCif}`,
            treasuryTypes.treasuryBond,
            depositsCurrencies,
            authorization,
            tracingHeaders
          ),
          await getTreasury(
            currentCif,
            currencyRates,
            mainCifCurrency,
            `securities/zbond/customer/${currentCif}`,
            treasuryTypes.zeroBond,
            depositsCurrencies,
            authorization,
            tracingHeaders
          )
        ]);
        treasury.push(treasuryBills, treasuryBond, zeroBonds);
        let total = treasuryBills.total + treasuryBond.total + zeroBonds.total;
        const billscount = treasuryBills.count;
        const bondscount = treasuryBond.count + zeroBonds.count;
        if (currency && currency !== defaultCurrency) {
          const { theRate } = await getCurrencyConversionRate(
            currency,
            currencyRates,
            tracingHeaders
          );
          treasury.forEach((product) => {
            product.total = Number((product.total * theRate).toFixed(2));
            product.currency = currency;
          });
          total *= theRate;
        }
        response[currentCountry] = {
          treasury,
          currency: currency ? currency : currentCifcurrency,
          total: Number(total.toFixed(2)),
          billscount,
          bondscount,
          depositsCurrencies: Array.from(depositsCurrencies)
        };
      }
    }
    if (mainCountry === countries.EG || Object.keys(response).length === 2) {
      return response[countries.EG];
    } else {
      return response.empty;
    }
  } catch (e) {
    logger.error(e);
    return {
      treasury: [],
      currency: currencies[countries.EG],
      total: 0,
      billscount: 0,
      bondscount: 0,
      depositsCurrencies: [`${currencies[countries.EG]}`],
      isError: true
    };
  }
};

export const getTreasury = async (
  user: number,
  currencyRates: any,
  currency: string,
  route: string,
  type: string,
  depositsCurrencies: any,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const data = {
      route,
      authorization
    };
    const producerData = await produce(data, tracingHeaders);
    const result = await prepareKafkaResponse(producerData);

    let total = 0;
    for (const item of result) {
      if (item.Currency !== currency) {
        if (currencyRates[item.Currency].method === 'M')
          total += item.PresentValue * currencyRates[item.Currency].TransferBuyRate;
        else total += item.PresentValue / currencyRates[item.Currency].TransferBuyRate;
      } else {
        total += item.PresentValue;
      }
      item.country = countries.EG;
      depositsCurrencies.add(item.Currency);
    }
    return {
      data: result,
      type,
      total,
      currency,
      count: result.length
    };
  } catch (e) {
    logger.error(e.message);
    return {
      data: [],
      type,
      total: 0,
      currency,
      count: 0
    };
  }
};

export const getCdTypesV2 = async (
  tracingHeaders: any,
  authorization: string,
  user: any,
  currency: string,
  query: any,
  language: string
) => {
  try {
    const userCertificates = await getOnlyUserCertificates(user, authorization, tracingHeaders);
    const data = {
      route: `ld/cd/types`
    };
    const producerData = await produce(data, tracingHeaders);
    let returnedCDTypes = await prepareKafkaResponse(producerData);

    if (query?.type) {
      const typeArray = query?.type.split(',');
      returnedCDTypes = returnedCDTypes.filter((element: any) => {
        return typeArray.includes(element.Type);
      });

      if (query?.category)
        returnedCDTypes = returnedCDTypes.map((x: any) => {
          const obj = {
            Type: x.Type,
            Types: x.Types.filter((e: any) => {
              return e.DescriptionEn.includes(query?.category) || e.Category === query?.category;
            })
          };
          return obj;
        });
    }

    returnedCDTypes = returnedCDTypes.filter((type: any) => availCdTypes.includes(type.Type));
    returnedCDTypes.forEach((type: any) => {
      type.multiplyInterest = type.Type !== 'Discounted';
      type.upFrontView = type.Type === 'Discounted';
      type.min = getCDMinAmount(type.Type, userCertificates);

      type.Types = type.Types.filter((CdType: any) => {
        CdType.FrequencyLabel = cdFrequencyMapping[language][CdType.Frequency];
        const validDenomination: boolean = CdType.ID.split('-')[2] === '1000';
        const isValidTenors: boolean = validCdsTenors.includes(parseInt(CdType.Tenor));
        if (type.Type === 'Discounted') {
          CdType.Frequency = CdType.Tenor;
          CdType.DescriptionAr = CdType.DescriptionAr || CdType.DescriptionEn;
          CdType.IntRate = CdType.BulletPercent;
          return parseInt(CdType.Tenor) === 36 && validDenomination;
        }

        if (type.Type === 'Bullet' && CdType.BulletPercent !== 0) {
          CdType.IntRate = CdType.BulletPercent;
        }
        return validDenomination && isValidTenors;
      });
      type.Title = cdTitle[language][type.Type];
      type.Describtion = cdTypeDesc[language][type.Type];
      type.isRenewable = type.Type !== 'Discounted';
      type.isInterestSameAccount = type.Type !== 'Discounted';
      type.frequencyStyle = type.Type === 'Fixed' ? 'edit' : 'read';
    });
    returnedCDTypes.sort((cdType1: any) => (cdType1.Type === 'Discounted' ? -1 : 0));
    return returnedCDTypes;
  } catch (e) {
    logger.error(e.message);
    throw new InternalError(e.message);
  }
};

export const getCdTypes = async (
  tracingHeaders: any,
  query: any,
  language: string,
  versionNumber: any
) => {
  try {
    const data = {
      route: `ld/cd/types`
    };
    const producerData = await produce(data, tracingHeaders);
    const CdTypes = await prepareKafkaResponse(producerData);
    let returnedCDTypes = CdTypes;
    try {
      if (query?.type) {
        const typeArray = query?.type.split(',');
        returnedCDTypes = CdTypes.filter((element: any) => {
          return typeArray.includes(element.Type);
        });

        if (query?.category)
          returnedCDTypes = returnedCDTypes.map((x: any) => {
            const obj = {
              Type: x.Type,
              Types: x.Types.filter((e: any) => {
                return e.DescriptionEn.includes(query?.category) || e.Category === query?.category;
              })
            };
            return obj;
          });
      }
      returnedCDTypes = returnedCDTypes.filter((type: any) => availCdTypes.includes(type.Type));

      returnedCDTypes.forEach((type: any) => {
        if (versionNumber)
          type.multiplyInterest = !(type.Type === 'Discounted' || type.Type === 'Bullet');
        else type.multiplyInterest = type.Type !== 'Discounted';
        type.upFrontView = type.Type === 'Discounted';
        type.firstTimeMin = minCdValues.firstTime;
        type.min = minCdValues.otherTimes;
        type.Types = type.Types.filter((CdType: any) => {
          CdType.FrequencyLabel = cdFrequencyMapping[language][CdType.Frequency];
          const validDenomination: boolean = CdType.ID.split('-')[2] === '1000';
          const isValidTenors: boolean = validCdsTenors.includes(parseInt(CdType.Tenor));
          if (type.Type === 'Discounted') {
            CdType.Frequency = CdType.Tenor;
            CdType.DescriptionAr = CdType.DescriptionAr || CdType.DescriptionEn;
            CdType.IntRate = CdType.BulletPercent;

            return parseInt(CdType.Tenor) === 36 && validDenomination;
          }

          if (type.Type === 'Bullet' && versionNumber && CdType.BulletPercent !== 0) {
            CdType.IntRate = CdType.BulletPercent;
          }

          return validDenomination && isValidTenors;
        });

        type.Title = cdTitle[language][type.Type];
        type.Describtion = cdTypeDesc[language][type.Type];
        type.isRenewable = type.Type !== 'Discounted';
        type.isInterestSameAccount = type.Type !== 'Discounted';
        type.frequencyStyle = type.Type === 'Fixed' ? 'edit' : 'read';
      });
      returnedCDTypes.sort((cdType1: any) => (cdType1.Type === 'Discounted' ? -1 : 0));
    } catch (error) {
      logger.error(error.message);
    }
    return returnedCDTypes;
  } catch (e) {
    logger.error(e.message);
    throw new InternalError(e.message);
  }
};

export const getCdTypesList = async (tracingHeaders: any, query: any, language: string) => {
  try {
    const data = {
      route: `ld/cd/types`
    };

    const producerData = await produce(data, tracingHeaders);
    const CdTypes = await prepareKafkaResponse(producerData);
    const allowedCdTypes = CdTypes.filter((CD: any) => availCdTypes.includes(CD.Type));

    const returndeCDTypes = allowedCdTypes.map((CD: any) => {
      const obj = {
        Type: CD.Type,
        Title: cdTitle[language][CD.Type],
        TitleAr: cdTitle['ar'][CD.Type],
        TitleEn: cdTitle['en'][CD.Type],
        Description: cdTypeDesc[language][CD.Type],
        DescriptionAr: cdTypeDesc['ar'][CD.Type],
        DescriptionEn: cdTypeDesc['en'][CD.Type],

        UpTo:
          CD.Types.map((CDminorType: any) => {
            if (CD.Type === 'Bullet' || CD.Type === 'Discounted') {
              CDminorType.IntRate = CDminorType.BulletPercent;
            }
            if (CDminorType.IntRate > 0) {
              return CDminorType.IntRate;
            }
          }).reduce(function (p: any, v: any) {
            return p > v ? p : v;
          }) || 0,

        Categories: [...new Map(CD.Types.map((item: any) => [item.Category, item])).values()].map(
          (t: any) => {
            return {
              Id: t.Category,
              Name: t.DescriptionEn
            };
          }
        )
      };
      return obj;
    });

    let finalResponseObje = returndeCDTypes;

    if (query?.type) {
      const typeArray = query?.type.split(',');
      finalResponseObje = returndeCDTypes.filter((element: any) => {
        return typeArray.includes(element.Type);
      });
    }
    return finalResponseObje;
  } catch (e) {
    logger.error(e.message);
    throw new InternalError(e.message);
  }
};

export const submitIssuance = async (
  issuance: SubmitIssuance,
  user: any,
  authorization: string,
  tracingHeaders: any,
  versionNumber: any
) => {
  await validateDebitAccount(issuance.DrawdownAccount);
  await validateDebitAccount(issuance.PrincipleAccount);
  await validateDebitAccount(issuance.ChargeAccount);
  const cdInfo = getCdInfo(issuance.CDType);
  try {
    const data = {
      route: `ld/cd/issuance/entry/input`,
      method: 'post',
      body: issuance,
      authorization
    };
    logger.info(`functionName: submitIssuance , integrationRoute: ${data.route} , user: ${user}`);
    const corrID = correlation.getId();
    logger.info(
      `functionName: submitIssuance, ${corrID},  issuanceBody: ${JSON.stringify(issuance, null, 2)}`
    );

    const producerData = await produce(data, tracingHeaders);
    const result = await prepareKafkaResponse(producerData);

    const cdCode = issuance.CDType;
    const cdType = cdCode.slice(-2);

    if (!versionNumber && cdType === 'BL') {
      const tenorInteresetMapping: any = {
        36: 9.97244489,
        60: 9.01948953,
        84: 8.49875439,
        120: 7.70154403
      };
      result.InterestRate = tenorInteresetMapping[cdInfo.tenor];
    }

    result.Message = '';

    return result;
  } catch (e) {
    logger.error(e.message);
    updateStatistics('', {
      cif: issuance.Customer,
      user: user.id,
      success: false,
      type: 'submit',
      subType: 'submitCdIssuance',
      cd: cdInfo.type,
      cdFrequency: cdInfo.frequency,
      tenor: cdInfo.tenor,
      date: new Date(),
      microservice: 'investment',
      amount: issuance.NumberOfCDs * 1000,
      interestAccount: issuance.IntrestAccount,
      chargeAccount: issuance.ChargeAccount,
      renew: issuance.RENEWAL
    });

    if (e.message === 'Not available to issue CD') throw new CDIssuanceNotValid(e.message);
    throw new InternalError(e.message);
  }
};

export const issueCdAndAuth = async (
  issuance: SubmitIssuance,
  user: any,
  authorization: string,
  tracingHeaders: any
) => {
  await validateDebitAccount(issuance.DrawdownAccount);
  await validateDebitAccount(issuance.PrincipleAccount);
  await validateDebitAccount(issuance.ChargeAccount);

  const cdInfo = getCdInfo(issuance.CDType);
  let TransactionId = '';
  try {
    const data = {
      route: `ld/cd/issuance/entry/input`,
      method: 'post',
      body: issuance,
      authorization
    };

    const producerData = await produce(data, tracingHeaders);

    const result = await prepareKafkaResponse(producerData);

    if (!result || result.Status === 'false' || !result?.TransactionId) {
      const error: Error = new Error();
      error.message = 'Failed to issue CD';
      error.name = 'issueCdFailed';
      throw error;
    }

    TransactionId = result?.TransactionId;

    logger.info(`New CD issued with txn id = ${TransactionId}`);

    if (TransactionId) {
      try {
        const authData = await authorizeIssuance(TransactionId, authorization, tracingHeaders);
      } catch (error) {
        throw new AuthCDError();
      }
    }

    result.Message = '';

    updateStatistics('', {
      cif: issuance.Customer,
      user: user.id,
      success: true,
      type: 'submit',
      subType: 'submitCdIssuanceAndAuthorize',
      cd: cdInfo.type,
      cdFrequency: cdInfo.frequency,
      tenor: cdInfo.tenor,
      date: new Date(),
      microservice: 'investment',
      amount: issuance.NumberOfCDs * 1000,
      interestAccount: issuance.IntrestAccount,
      chargeAccount: issuance.ChargeAccount,
      renew: issuance.RENEWAL
    });

    return result;
  } catch (e) {
    logger.error(e.message);
    if (e.name === 'authCdFailed') {
      await cancelIssuance(TransactionId, authorization, tracingHeaders);
    }
    updateStatistics('', {
      cif: issuance.Customer,
      user: user.id,
      success: false,
      type: 'submit',
      subType: 'submitCdIssuanceAndAuthorize',
      cd: cdInfo.type,
      cdFrequency: cdInfo.frequency,
      tenor: cdInfo.tenor,
      date: new Date(),
      microservice: 'investment',
      amount: issuance.NumberOfCDs * 1000,
      interestAccount: issuance.IntrestAccount,
      chargeAccount: issuance.ChargeAccount,
      renew: issuance.RENEWAL
    });
    if (e instanceof AuthCDError || e.type === 'AuthCDError') {
      throw new AuthCDError(e.message);
    } else {
      throw new InternalError(e.message);
    }
  }
};

export const validateDebitAccount = async (Acc: string) => {
  const draftAccRegex = /^[0-9]{8}15[0-9][1-9][0-9]{4}$/;
  if (draftAccRegex.test(Acc)) throw new ForbiddenError(messages.accounts.overDraftAccount.en);
};

export const authorizeIssuance = async (
  transactionID: string,
  authorization: string,
  tracingHeaders: any,
  userName?: string
) => {
  try {
    const data = {
      route: `ld/cd/submit/authorize`,
      method: 'post',
      body: {
        Company: '',
        UserId: '',
        Pwd: '',
        transactionID
      },
      authorization
    };

    logger.info(
      `functionName: authorizeIssuance , integrationRoute: ${data.route}, transactionID: ${data.body.transactionID}`
    );

    const result = await produce(data, tracingHeaders, true);
    await prepareKafkaResponse(result);

    const cdData = {
      route: `ld/certificate/${transactionID}`,
      method: 'get',
      authorization
    };

    const cdProduce = await produce(cdData, tracingHeaders, true);
    let cdResult = await prepareKafkaResponse(cdProduce);
    cdResult = cdResult[0];

    const cdInfo = getCdInfo(cdResult.LDType);

    updateStatistics('', {
      cif: cdResult.Customer,
      user: userName,
      success: true,
      type: 'authorize',
      subType: 'authorizeCd',
      cd: cdInfo.type,
      cdFrequency: cdInfo.frequency,
      tenor: cdInfo.tenor,
      date: new Date(),
      microservice: 'investment',
      amount: cdResult.LDAmount,
      interestAccount: cdResult.InterestAccount,
      chargeAccount: cdResult.ChargeAccount,
      renew: cdResult.Renewal
    });

    return { message: 'Success' };
  } catch (e) {
    logger.error(`functionName:authorizeIssuance , errorMsg: ${e} `);
    throw new InternalError(e.message);
  }
};

export const cancelIssuance = async (
  transactionID: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const data = {
      route: `ld/cd/submit/cancel`,
      method: 'post',
      body: {
        Company: '',
        UserId: '',
        Pwd: '',
        transactionID
      },
      authorization
    };
    const result = await produce(data, tracingHeaders);
    await prepareKafkaResponse(result);
    return { message: 'Success' };
  } catch (e) {
    logger.error(e.message);
    if (e.message === 'Only New Contracts Allowed.') throw new CDCancelError();
    else throw new InternalError(e.message);
  }
};

export const getUnAuthCertificates = async (
  authorization: string,
  cif: string,
  tracingHeaders: any
) => {
  try {
    const data = {
      route: `ld/certificate/unauth/customer/${cif}`,
      authorization
    };
    const producerData = await produce(data, tracingHeaders);
    const resp = await prepareKafkaResponse(producerData);
    resp.map((CD: any) => {
      CD.UnAuthorized = true;
      CD.Amount = CD.LDAmount;
    });
    return { CDData: resp, isError: false };
  } catch (e) {
    logger.error(`FunctionName: getUnAuthCertificates/${cif} #### Error: ${e.message}`);
    return { CDData: [], isError: true };
  }
};

export const requestSecuredLoan = async (
  cif: string,
  user: string,
  phoneNumber: string,
  productDetails: string,
  platform: string,
  tracingHeaders: any
) => {
  try {
    const data = {
      topic: kafkaTopics.smtp,
      function: 'sendEmailService',
      cif,
      productDetails,
      body: { productDetails },
      template: productDetails ? 'requestSecuredLoanWithCD' : 'requestSecuredLoan'
    };
    await produce(data, tracingHeaders, false);
    updateStatistics('', {
      cif,
      user,
      mobile: phoneNumber,
      type: 'request',
      subType: 'requestSecuredLoan',
      requestDetail: productDetails,
      date: new Date(),
      microservice: 'investment',
      platform
    }).catch((e) => e.message);
    return { message: 'Success' };
  } catch (e) {
    logger.error(e.message);
    throw new InternalError(e.message);
  }
};

export const requestTopUpLoan = async (
  cif: string,
  user: string,
  phoneNumber: string,
  loanName: string
) => {
  try {
    const body = {};
    const data = {
      topic: kafkaTopics.smtp,
      function: 'sendEmailService',
      body,
      cif,
      template: 'topUpLoan'
    };
    await produce(data, null, false);
    updateStatistics('', {
      cif,
      user,
      mobile: phoneNumber,
      type: 'request',
      subType: 'loanTopUpRequest',
      requestDetail: loanName,
      date: new Date(),
      microservice: 'investment'
    }).catch((e) => e.message);
    return { message: 'Success' };
  } catch (e) {
    logger.error(e.message);
    throw new InternalError(e.message);
  }
};

export const bookSecuredLoan = async (
  authorization: string,
  cif: string,
  userName: string,
  body: Partial<{
    Customer: string;
    LoanType: string;
    Amount: number;
    DisbursmentAccount: string;
    InstLiqAccount: string;
    Currency: string;
    Tenor: number;
    ContractReference: string;
    ContractDets: any;
    transactionID: string;
  }>,
  tracingHeaders: any
) => {
  try {
    await validateDebitAccount(body.DisbursmentAccount as string);
    const getCertData = {
      route: `ld/certificate/${body.ContractReference}`,
      authorization
    };
    let producerData = await produce(getCertData, tracingHeaders);
    const contractDets = await prepareKafkaResponse(producerData);
    body.Customer = cif;
    body.ContractDets = contractDets;
    const data = {
      route: `ld/loan/secured/entry/input`,
      method: 'post',
      body: body,
      authorization
    };
    producerData = await produce(data, tracingHeaders);
    const result = await prepareKafkaResponse(producerData);
    updateStatistics('', {
      date: new Date(),
      type: 'loan',
      subType: 'securedLoan',
      cif,
      userName,
      success: true,
      pledgedProduct: 'CD',
      productId: body.ContractReference,
      amount: body.Amount,
      tenor: body.Tenor,
      DisbursmentAccount: body.DisbursmentAccount,
      InstLiqAccount: body.InstLiqAccount,
      reason: ' '
    });
    return result;
  } catch (e) {
    logger.error(e.message);
    updateStatistics('', {
      date: new Date(),
      type: 'loan',
      subType: 'securedLoan',
      cif,
      userName,
      success: false,
      pledgedProduct: 'CD',
      productId: body.ContractReference,
      amount: body.Amount,
      tenor: body.Tenor,
      DisbursmentAccount: body.DisbursmentAccount,
      InstLiqAccount: body.InstLiqAccount,
      reason: e.message
    });
    if (e.message === messages.securedLoan.iScoreRejection.en) throw new BadRequestError(e.message);
    throw new InternalError(e.message);
  }
};

export const getCdInfo = (cdType: string) => {
  const cdInfo: any = {};
  cdInfo.tenor = parseInt(cdType.split('-')[0]);
  cdInfo.type = mapToCdType(cdType.substring(14));
  cdInfo.frequency = mapToFrequency(cdType.split('-')[1]);
  return cdInfo;
};

export const mapToFrequency = (frequency: string) => {
  switch (frequency) {
    case 'null':
      return 'full-time-CD';
    case '01':
      return 'monthly';
    case '03':
      return 'quarterly';
    case '06':
      return 'semiAnnually';
    default:
      return 'annually';
  }
};

export const mapToCdType = (type: string) => {
  switch (type) {
    case 'FL':
      return 'floating';
    case 'BL':
      return 'bullet';
    case 'DS':
      return 'Upfront';
    default:
      return 'fixed';
  }
};
export const sortRecordsDes = (records: Array<any>, field: string) => {
  return records.length ? records.sort((a, b) => b[field] - a[field]) : records;
};

export const getCdSourceOfFund = (
  tracingHeaders: any
): { code: number; ARName: string; ENName: string }[] => {
  return CdSourceOfFund;
};

export const getRedemptionTable = (language: string) => {
  try {
    return redemptionTable[language];
  } catch (e: any) {
    logger.debug(e.message);
    throw new InternalError(e.message);
  }
};

const getCDMinAmount = (cdType: string, userInvestment: any): number => {
  cdType = cdType.toLowerCase();

  if (cdType === 'bullet' || cdType === 'fixed') {
    const hasBulletOrFixed = userInvestment.some((cd: any) => {
      const userCDType = cd.LDTypeDescription.split(' ')[0].toLowerCase();
      return userCDType === 'bullet' || userCDType === 'fixed';
    });

    return hasBulletOrFixed ? 1000 : 5000;
  }

  if (cdType === 'discounted') {
    const hasDiscounted = userInvestment.some((cd: any) => {
      const userCDType = cd.LDTypeDescription.split(' ')[0].toLowerCase();
      return userCDType === 'discounted';
    });

    return hasDiscounted ? 1000 : 5000;
  }

  return 5000;
};

const getOnlyUserCertificates = async (
  user: any,
  authorization: any,
  tracingHeaders: any,
  country = 'EG'
) => {
  try {
    const data = {
      route: `ld/certificate/customer/${user}`,
      authorization,
      country
    };

    const producerData = await produce(data, tracingHeaders, true);
    const result = await prepareKafkaResponse(producerData);

    return result;
  } catch (e) {
    logger.error('functionName: get only certificates', e.message);
    throw new InternalError(e.message);
  }
};
