export const redemptionTable: any = {
  en: [
    {
      type: 'upFrontCd',
      title: 'Upfront CD Redemption table',
      columns: [
        {
          field: 'dur',
          header: 'DUR'
        },
        {
          field: 'yrs1',
          header: ''
        }
      ],
      rowData: [
        {
          id: '1',
          dur: 'Yr 1',
          yrs1: '95.00%'
        },
        {
          id: '2',
          dur: 'Yr 2',
          yrs1: '63.00%'
        },
        {
          id: '3',
          dur: 'Yr 3',
          yrs1: '28.00%'
        }
      ]
    },
    {
      type: 'fixedCd',
      title: 'Fixed CD Redemption table',
      columns: [
        {
          field: 'dur',
          header: 'DUR'
        },
        {
          field: 'yrs3',
          header: '3yrs'
        },
        {
          field: 'yrs5',
          header: '5yrs'
        },
        {
          field: 'yrs7',
          header: '7yrs'
        },
        {
          field: 'yrs10',
          header: '10yrs'
        }
      ],
      rowData: [
        {
          id: 1,
          dur: 'Yr 1',
          mnths: '17.25%',
          yrs3: '7%',
          yrs5: '3%',
          yrs7: '3.25%',
          yrs10: '3.50%'
        },
        {
          id: 2,
          dur: 'Yr 2',
          mnths: '16.25%',
          yrs3: '6%',
          yrs5: '2.75%',
          yrs7: '3%',
          yrs10: '3.25%'
        },
        {
          id: 3,
          dur: 'Yr 3',
          mnths: '',
          yrs3: '5%',
          yrs5: '2.25%',
          yrs7: '2.75%',
          yrs10: '3%'
        },
        {
          id: 4,
          dur: 'Yr 4',
          mnths: '',
          yrs3: '',
          yrs5: '2%',
          yrs7: '2.25%',
          yrs10: '2.75%'
        },
        {
          id: 5,
          dur: 'Yr 5',
          mnths: '',
          yrs3: '',
          yrs5: '1.75%',
          yrs7: '2%',
          yrs10: '2.5%'
        },
        {
          id: 6,
          dur: 'Yr 6',
          mnths: '',
          yrs3: '',
          yrs5: '',
          yrs7: '1.75%',
          yrs10: '2.25%'
        },
        {
          id: 7,
          dur: 'Yr 7',
          mnths: '',
          yrs3: '',
          yrs5: '',
          yrs7: '1.50%',
          yrs10: '2%'
        },
        {
          id: 8,
          dur: 'Yr 8',
          mnths: '',
          yrs3: '',
          yrs5: '',
          yrs7: '',
          yrs10: '1.75%'
        },
        {
          id: 9,
          dur: 'Yr 9',
          mnths: '',
          yrs3: '',
          yrs5: '',
          yrs7: '',
          yrs10: '1.5%'
        },
        {
          id: 10,
          dur: 'Yr 10',
          mnths: '',
          yrs3: '',
          yrs5: '',
          yrs7: '',
          yrs10: '1.25%'
        }
      ]
    },
    {
      type: 'bulletCd',
      title: 'Bullet CD Redemption table',
      columns: [
        {
          field: 'dur',
          header: 'DUR'
        },
        {
          field: 'yrs3',
          header: 'Yr 3'
        },
        {
          field: 'yrs5',
          header: 'Yr 5'
        },
        {
          field: 'yrs7',
          header: 'Yr 7'
        },
        {
          field: 'yrs10',
          header: 'Yr 10'
        }
      ],
      rowData: [
        {
          id: 1,
          dur: 'Yr 1',
          yrs3: '7%',
          yrs5: '7%',
          yrs7: '7%',
          yrs10: '7%'
        },
        {
          id: 2,
          dur: 'Yr 2',
          yrs3: '6%',
          yrs5: '6%',
          yrs7: '6%',
          yrs10: '6.5%'
        },
        {
          id: 3,
          dur: 'Yr 3',
          yrs3: '5%',
          yrs5: '5%',
          yrs7: '5%',
          yrs10: '6%'
        },
        {
          id: 4,
          dur: 'Yr 4',
          yrs3: '',
          yrs5: '4%',
          yrs7: '4%',
          yrs10: '5.5%'
        },
        {
          id: 5,
          dur: 'Yr 5',
          yrs3: '',
          yrs5: '3%',
          yrs7: '3%',
          yrs10: '5%'
        },
        {
          id: 6,
          dur: 'Yr 6',
          yrs3: '',
          yrs5: '',
          yrs7: '2%',
          yrs10: '4.5%'
        },
        {
          id: 7,
          dur: 'Yr 7',
          yrs3: '',
          yrs5: '',
          yrs7: '1%',
          yrs10: '4%'
        },
        {
          id: 8,
          dur: 'Yr 8',
          yrs3: '',
          yrs5: '',
          yrs7: '',
          yrs10: '3%'
        },
        {
          id: 9,
          dur: 'Yr 9',
          yrs3: '',
          yrs5: '',
          yrs7: '',
          yrs10: '2%'
        },
        {
          id: 10,
          dur: 'Yr 10',
          yrs3: '',
          yrs5: '',
          yrs7: '',
          yrs10: '1%'
        }
      ]
    }
    // {
    //   type: 'floatingCd',
    //   title: 'Floating CD Redemption table',
    //   columns: [
    //     {
    //       field: 'dur',
    //       header: 'DUR'
    //     },
    //     {
    //       field: 'yrs3',
    //       header: 'Yr 3'
    //     },
    //     {
    //       field: 'yrs5',
    //       header: 'Yr 5'
    //     }
    //   ],
    //   rowData: [
    //     {
    //       id: 1,
    //       dur: 'Yr 1',
    //       yrs3: '3.0000%',
    //       yrs5: '2.7500%'
    //     },
    //     {
    //       id: 2,
    //       dur: 'Yr 2',
    //       yrs3: '2.0000%',
    //       yrs5: '2.2500%'
    //     },
    //     {
    //       id: 3,
    //       dur: 'Yr 3',
    //       yrs3: '1.0000%',
    //       yrs5: '1.5000%'
    //     },
    //     {
    //       id: 4,
    //       dur: 'Yr 4',
    //       yrs3: '',
    //       yrs5: '1.2500%'
    //     },
    //     {
    //       id: 5,
    //       dur: 'Yr 5',
    //       yrs3: '',
    //       yrs5: '1.0000%'
    //     }
    //   ]
    // }
  ],
  ar: [
    {
      type: 'upFrontCd',
      title: 'جدول الاسترداد للشهادات ذات العائد المدفوع مقدماً',
      columns: [
        {
          field: 'dur',
          header: 'المدة'
        },
        {
          field: 'yrs1',
          header: ''
        }
      ],
      rowData: [
        {
          id: '1',
          dur: 'السنة 1',
          yrs1: '95.00%'
        },
        {
          id: '2',
          dur: 'السنة 2',
          yrs1: '63.00%'
        },
        {
          id: '3',
          dur: 'السنة 3',
          yrs1: '28.00%'
        }
      ]
    },
    {
      type: 'fixedCd',
      title: 'جدول الاسترداد للشهادات ذات العائد الثابت',
      columns: [
        {
          field: 'dur',
          header: 'المدة'
        },
        {
          field: 'yrs3',
          header: 'س3'
        },
        {
          field: 'yrs5',
          header: 'س3'
        },
        {
          field: 'yrs7',
          header: 'س7'
        },
        {
          field: 'yrs10',
          header: 'س10'
        }
      ],
      rowData: [
        {
          id: 1,
          dur: 'السنة 1',
          mnths: '17.25%',
          yrs3: '7%',
          yrs5: '3%',
          yrs7: '3.25%',
          yrs10: '3.50%'
        },
        {
          id: 2,
          dur: 'السنة 2',
          mnths: '16.25%',
          yrs3: '6%',
          yrs5: '2.75%',
          yrs7: '3%',
          yrs10: '3.25%'
        },
        {
          id: 3,
          dur: 'السنة 3',
          mnths: '',
          yrs3: '5%',
          yrs5: '2.25%',
          yrs7: '2.75%',
          yrs10: '3%'
        },
        {
          id: 4,
          dur: 'السنة 4',
          mnths: '',
          yrs3: '',
          yrs5: '2%',
          yrs7: '2.25%',
          yrs10: '2.75%'
        },
        {
          id: 5,
          dur: 'السنة 5',
          mnths: '',
          yrs3: '',
          yrs5: '1.75%',
          yrs7: '2%',
          yrs10: '2.5%'
        },
        {
          id: 6,
          dur: 'السنة 6',
          mnths: '',
          yrs3: '',
          yrs5: '',
          yrs7: '1.75%',
          yrs10: '2.25%'
        },
        {
          id: 7,
          dur: 'السنة 7',
          mnths: '',
          yrs3: '',
          yrs5: '',
          yrs7: '1.50%',
          yrs10: '2%'
        },
        {
          id: 8,
          dur: 'السنة 8',
          mnths: '',
          yrs3: '',
          yrs5: '',
          yrs7: '',
          yrs10: '1.75%'
        },
        {
          id: 9,
          dur: 'السنة 9',
          mnths: '',
          yrs3: '',
          yrs5: '',
          yrs7: '',
          yrs10: '1.5%'
        },
        {
          id: 10,
          dur: 'السنة 10',
          mnths: '',
          yrs3: '',
          yrs5: '',
          yrs7: '',
          yrs10: '1.25%'
        }
      ]
    },
    {
      type: 'bulletCd',
      title: 'جدول الاسترداد للشهادات ذات العائد التراكمى',
      columns: [
        {
          field: 'dur',
          header: 'المدة'
        },
        {
          field: 'yrs3',
          header: 'س3'
        },
        {
          field: 'yrs5',
          header: 'س5'
        },
        {
          field: 'yrs7',
          header: 'س7'
        },
        {
          field: 'yrs10',
          header: 'س10'
        }
      ],
      rowData: [
        {
          id: 1,
          dur: 'السنة 1',
          yrs3: '7%',
          yrs5: '7%',
          yrs7: '7%',
          yrs10: '7%'
        },
        {
          id: 2,
          dur: 'السنة 2',
          yrs3: '6%',
          yrs5: '6%',
          yrs7: '6%',
          yrs10: '6.5%'
        },
        {
          id: 3,
          dur: 'السنة 3',
          yrs3: '5%',
          yrs5: '5%',
          yrs7: '5%',
          yrs10: '6%'
        },
        {
          id: 4,
          dur: 'السنة 4',
          yrs3: '',
          yrs5: '4%',
          yrs7: '4%',
          yrs10: '5.5%'
        },
        {
          id: 5,
          dur: 'السنة 5',
          yrs3: '',
          yrs5: '3%',
          yrs7: '3%',
          yrs10: '5%'
        },
        {
          id: 6,
          dur: 'السنة 6',
          yrs3: '',
          yrs5: '',
          yrs7: '2%',
          yrs10: '4.5%'
        },
        {
          id: 7,
          dur: 'السنة 7',
          yrs3: '',
          yrs5: '',
          yrs7: '1%',
          yrs10: '4%'
        },
        {
          id: 8,
          dur: 'السنة 8',
          yrs3: '',
          yrs5: '',
          yrs7: '',
          yrs10: '3%'
        },
        {
          id: 9,
          dur: 'السنة 9',
          yrs3: '',
          yrs5: '',
          yrs7: '',
          yrs10: '2%'
        },
        {
          id: 10,
          dur: 'السنة 10',
          yrs3: '',
          yrs5: '',
          yrs7: '',
          yrs10: '1%'
        }
      ]
    }
    // {
    //     type: 'floatingCd',
    //     title: 'جدول الاسترداد للشهادات ذات العائد المتغير',
    //     columns: [
    //         {
    //             field: 'dur',
    //             header: 'المدة'
    //         },
    //         {
    //             field: 'yrs3',
    //             header: 'السنة 3'
    //         },
    //         {
    //             field: 'yrs5',
    //             header: 'السنة 5'
    //         }
    //     ],
    //     rowData: [
    //         {
    //             id: 1,
    //             dur: 'السنة 1',
    //             yrs3: '3.0000%',
    //             yrs5: '2.7500%'
    //         },
    //         {
    //             id: 2,
    //             dur: 'السنة 2',
    //             yrs3: '2.0000%',
    //             yrs5: '2.2500%'
    //         },
    //         {
    //             id: 3,
    //             dur: 'السنة 3',
    //             yrs3: '1.0000%',
    //             yrs5: '1.5000%'
    //         },
    //         {
    //             id: 4,
    //             dur: 'السنة 4',
    //             yrs3: '',
    //             yrs5: '1.2500%'
    //         },
    //         {
    //             id: 5,
    //             dur: 'السنة 5',
    //             yrs3: '',
    //             yrs5: '1.0000%'
    //         }
    //     ]
    // }
  ]
};
