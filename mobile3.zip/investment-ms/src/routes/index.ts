import express from 'express';
import investment from './investment/investment';

const router = express.Router();

router.use('/investment', investment);

export default router;
