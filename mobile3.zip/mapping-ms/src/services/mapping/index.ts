import { KafkaMessage } from 'kafkajs';
import { Language } from 'app-request';
import { mapping, debitMapping } from '../../helpers/mapping';
import { InternalError } from '../../core/ApiError';
import { defaultLanguage } from '../../config';
import messages from '../../messages';
import { logger } from '../../core/Logger';

export const getMappingData = async (language: Language) => {
  return mapping[language] || mapping[defaultLanguage];
};

export const getCardMappingData = async (language: Language) => {
  return debitMapping[language] || debitMapping[defaultLanguage];
};

export const prepareKafkaResponse = async (message: KafkaMessage) => {
  if (!message.value) throw new InternalError(messages.accounts.missingValue.en);
  const data = JSON.parse(message.value.toString());
  if (!data.error) {
    return data.message.Data || data.message.data;
  } else {
    logger.debug(data.message);
    throw new InternalError(messages.accounts.internalError.en);
  }
};
