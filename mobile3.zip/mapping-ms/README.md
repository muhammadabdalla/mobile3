# AAIB Mapping Microservice


* How to build and run this project 
    * Clone this repo.
    * Run npm install.
    * Make a copy of **.env.example** file to **.env**.
    * Run the following command: npm start
    
    
    
* How to run the mapping script
    * Run npm run mapping
    * A file called mapping.json will be created
    * Update the mapping.ts file using the new content generated
    * Restart the service
